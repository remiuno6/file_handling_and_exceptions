def read_and_write_file():
    # Ask the user for a filename
    filename = input("Enter the filename to read: ")
    new_filename = input("Enter the new filename to save the modified content: ")
    
    try:
        # Try opening the file in read mode
        with open(filename, "r") as file:
            # Read the content of the file
            content = file.read()

            # Modify the content (for example, converting text to uppercase)
            modified_content = content.upper()  # Modify as per requirement
            
            # Write the modified content to a new file
            with open(new_filename, "w") as new_file:
                new_file.write(modified_content)
                
            print(f"The modified content has been saved to {new_filename}")
    
    except FileNotFoundError:
        print(f"Error: The file {filename} does not exist.")
    
    except IOError:
        print(f"Error: Could not read or write to the file.")

# Call the function
read_and_write_file()
